# alpha更新日志

重大行为变化：magiskd现在位于独立挂载命名空间，这也是su的全局挂载命名空间。
大部分su用例不会受到影响，如需init挂载命名空间，改为`su -t 1`。

重大行为变化：magiskd内部挂载点对外隐藏，并于不再使用后卸载。

## Magisk (f7e47161-alpha)
- [App] 还原boot镜像后删除备份文件
- [General] 不自动解锁设备块
- [App] 不主动请求权限
- [General] 保留ROOTOVL临时文件
- [Zygisk] 卸载挂载不跳过com.android.systemui
- [App] 通过appcenter检查和下载更新
- [App] 添加遥测 https://t.me/s/magiskalpha/473
- [General] 使阻止列表在zygisk未启用时可以工作
- [General] 移除addon.d支持
- [General] 隐藏并清理magiskd内部挂载点
- [General] 取消/system/etc/hosts可写的例外,请修改/data/adb/modules/hosts/system/etc/hosts
- [MagiskSU] 支持移除权能
- [General] 支持用户限制Root权能 [使用旧版libsu的应用会错误识别为无root]
- [General] 初始安装后自动复制文件
- [App] 添加备用DoH服务器
- [General] 安全模式不再挂载su到/system/bin/su，adb shell请使用/debug_ramdisk/su
- [MagiskBoot] cpio备份时压缩文件
- [General] 模块文件原子挂载
- [Zygisk] 支持Android14 QPR2

# 上游更新日志

## Magisk (1dcf3255) (26402)

- [Zygisk] Introduce new code injection mechanism

## Diffs to v26.4

- [Zygisk] Introduce new code injection mechanism
